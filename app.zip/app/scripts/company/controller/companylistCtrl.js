angular.module ("myapp")
       .controller ("companylistCtrl",[
           "$scope",
           "$state",
           "myCompanyService", function (
           $scope,
           $state,
           myCompanyService) {

        var init = function init () {
            $scope.cdetails = {};
            myCompanyService.doGetCompanies(cSuccess);
        };

        function cSuccess (response) {
            $scope.cdetails.data = response;
        };

        $scope.onEdit = function onEdit (companyid) {
            $state.go ('root.home.company.list.details', {id : companyid});
        };

        $scope.onDelete = function onDelete (id) {
            myCompanyService.doDeleteMyCompanydetails (id);
        };

        $scope.onCancel = function onCancel () {
            $state.go ('root.home.company.list')
        };

        init ();
}]);
