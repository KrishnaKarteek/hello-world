angular.module ('myapp')
       .service ('myCompanyService',
            [ "$http",
              "localStorageService", function (
              $http,
              localStorageService) {

            this.items = [];
            this.doGetCompanies = function doGetCompanies (cSuccess) {
                 this.items = this.dogetCompaniesFromLocalstorage ();
                if (!this.items) {
                    $http.get ('data/companyDetails.json')
                        .then (function(response) {
                            localStorageService.create ('companyDetails', response.data);
                            cSuccess (response.data);
                        })
                } else {
                    cSuccess (this.items);
                }
            };

            this.doUpdateinMyCompanyStorage = function doUpdateinMyCompanyStorage (company,id) {
                localStorageService.update (company, id, 'companyDetails');
            };

            this.doPutMyCompanyDetails = function doPutMyCompanyDetails (newCompany) {
                var companies = this.dogetCompaniesFromLocalstorage();
                companies.push (newCompany);
                localStorageService.create ('companyDetails', companies);
                location.reload ();
            };

            this.doGetCompanyDetailsByID = function doGetCompanyDetailsByID (id) {
                    return localStorageService.getItem ('companyDetails', id);
            };

            this.dogetCompaniesFromLocalstorage = function dogetCompaniesFromLocalstorage () {
                return localStorageService.getItems ('companyDetails');
            };

            this.doDeleteMyCompanydetails = function doDeleteMyCompanydetails (id) {
                this.dogetItem ('companyDetails',id);
                location.reload ();
            };

            this.doGetMaxValueOfID = function doGetMaxValueOfID () {
                return localStorageService.getMaxID('companyDetails');
            };

            this.dogetItem = function dogetItem (key, id) {
                var items = localStorage.getItem (key);
                items = JSON.parse (items);
                var item = {};
                for (var i = 0; i <items.length; i++) {
                    if (id == items[i].id) {
                        items.splice(i,1);
                        item = items[i];
                    }
                }
                localStorageService.create ('companyDetails', items);
            };

        }]);
