angular.module ('myapp')
       .controller ('companyDetailsCtrl',[
           '$scope',
           '$state',
           'myCompanyService', function (
           $scope,
           $state,
           myCompanyService) {

        function init () {
            $scope.existingCompanyDetails = {};
            $scope.companyMetaInfo = {};
            var companyid = $state.params.id;
            if (companyid) {
                $scope.companyMetaInfo = myCompanyService.doGetCompanyDetailsByID (companyid);
            }
            existingCompanyDetails = angular.copy ($scope.companyMetaInfo);
        };

        $scope.onUpdate = function onUpdate (companyid) {
            myCompanyService.doUpdateinMyCompanyStorage ($scope.companyMetaInfo,companyid);
            $state.go('root.home.company.list')
        };

        $scope.onReset = function onReset () {
            $scope.companyMetaInfo = angular.copy (existingCompanyDetails);
        };

        $scope.onCancel = function onCancel () {
         $state.go ('root.home.company.list')
        };

        $scope.onSave = function onSave (name, employees) {
            var companyid = $state.params.id;
            if (companyid == false) {
                var newCompany = {
                    "id" : myCompanyService.doGetMaxValueOfID () + 1,
                    "name" : name,
                    "Employees" : employees
                };
                myCompanyService.doPutMyCompanyDetails (newCompany);
                $state.go ('root.home.company.list')
            } else {
                this.onUpdate (companyid);
            }
        };

        init();

}]);
