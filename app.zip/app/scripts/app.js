angular.module('myapp', ["ui.router"])
    .config(function($stateProvider, $urlRouterProvider){


      $stateProvider
          .state('root', {
              abstract: true,
              url:''
          })
          .state('root.home', {
              url: '/home',
              templateUrl: 'views/home.html',
              onEnter: function(){
                  console.log("enter contacts.detail");
              }
          }).state('root.home.company', {
              url: '/company',

              templateUrl: 'views/company/companyPanel.html',
              onEnter: function(){
                  console.log("enter contacts.detail");
              }
          }).state('root.home.company.list',{
              url : '/list',
              controller : 'companylistCtrl',
              templateUrl : 'views/company/companyList.html',
              onEnter : function() {
                console.log("enter content.details");
              }
          }).state('root.home.company.list.details',{
              url : '/details/:id',
              controller : 'companyDetailsCtrl',
              templateUrl : 'views/company/details.html',
              onEnter : function() {
                console.log("enter content.details");
            }
          }).state('root.home.employee', {
            url: '/employee',
            templateUrl: 'views/employee/employeePanel.html',

            onEnter: function(){
                console.log("enter contacts.detail");
            }
        });

        $urlRouterProvider.otherwise("/home");
    });
