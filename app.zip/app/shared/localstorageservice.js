angular.module ('myapp')
       .service ('localStorageService',
            function () {
                this.create = function create (key, response) {
                    localStorage.setItem (key, JSON.stringify(response));
                };

                this.update = function update (item, id, key) {
                    var items = this.getItems (key);
                    items.splice((id-1), 1, item);
                    this.create (key, items);
                    location.reload();
                };

                this.getItems = function getItems (key) {
                    var items = localStorage.getItem(key);
                    return JSON.parse(items);
                };

                this.getMaxID = function getMaxID (key) {
                    var items = localStorage.getItem(key);
                    items = JSON.parse(items);
                    var length = items.length ;
                    return length;
                };

                this.getItem = function getItem (key, id) {
                    var items = localStorage.getItem(key);
                    items = JSON.parse(items);
                    var item = {};
                    for (var i = 0; i <items.length; i++) {
                        if (id == items[i].id) {
                            item = items[i];
                        }
                    }
                    return item;
                };

            });
