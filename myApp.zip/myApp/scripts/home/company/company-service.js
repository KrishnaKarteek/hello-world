angular.module('myapp-company')
	.service('getLocalStorage',['$localStorage',  function ($localStorage) {                  
                 
                    this.updateCompanies = function (companiesArr) {  
						$localStorage.companiesList = companiesArr;
               		
                };  
  
            }]);  