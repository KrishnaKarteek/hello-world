angular.module('myapp-company', ['ngStorage'])
	.controller('companyctrl', ['$scope',
								'$rootScope',
								'getLocalStorage', 
								'$state', 
								'$http', 
								'$localStorage', function(
								 $scope,
								 $rootScope,
								 getLocalStorage, 
								 $state, 
								 $http, 
								 $localStorage){
		
		var init = function(){
				 $http.get("/app/data/company/companyData.json").then(function (response) {
					 if(!$localStorage.companiesList == response.data){
						$localStorage.companiesList =  response.data;
					 }
					 else{
						 $scope.companiesList = $localStorage.companiesList;
					 }
					});
					
					//this.companiesListToGetIndex = {};
					companiesListToGetIndex = $localStorage.companiesList;
		}	
		
	
		
		
		
		 $scope.onAddCompany = function () { 
							
							if($scope.cmpName != null){
								$scope.companiesList.push({ 'name': $scope.cmpName, 'year': $scope.cmpYear, 'revenue': $scope.cmpRevenue, 'employees': $scope.cmpEmployees});    
								getLocalStorage.updateCompanies($scope.companiesList);    
 								$scope.cmpName = '';    
								$scope.cmpYear = '';    
								$scope.cmpRevenue = '';       
								$scope.cmpEmployees = '';    
								$rootScope.showContent = false;								
							}
							else{
								alert("Please enter Name");
							}
							
							
							
		};   
								
	
		 $scope.onDeleteCompany = function (cmp) {                       
			$scope.companiesList.splice($scope.companiesList.indexOf(cmp), 1);    
			getLocalStorage.updateCompanies($scope.companiesList);    
				  
		}; 
		
		$scope.onCancel = function(){
			$rootScope.showContent = false;
		
		};
		
			 
		$scope.onEditCompany = function(cmp){
			indx = companiesListToGetIndex.indexOf(cmp);
			$scope.comp = {};
			$rootScope.showContent = true;
			$scope.comp.name = cmp.name;
			$scope.comp.year = cmp.year;
			$scope.comp.revenue = cmp.revenue;
			$scope.comp.employees = cmp.employees;
			$scope.duplicate = angular.copy(cmp);
			$state.go("home.company.companyList.editCompany");
			
			$scope.onResetCompany = function(){
				$rootScope.showContent = true;
				$scope.comp = angular.copy($scope.duplicate);	
			};
			
			$scope.onSaveCompany = function(newComp){
				$rootScope.showContent = false;
				$scope.comp.name = newComp.name;
				$scope.comp.year = newComp.year;
				$scope.comp.revenue = newComp.revenue;
				$scope.comp.employees = newComp.employees;
				
				
				
				$scope.companiesList.splice(indx, 1, $scope.comp);    
				getLocalStorage.updateCompanies($scope.companiesList);    
				
				//$localStorage.companiesList = $scope.companiesList;
				//getLocalStorage.updateCompanies($scope.companiesList); 
			}
		
		};
		
		$scope.onAddNewCompany = function(){
			$rootScope.showContent = true;
			$state.go("home.company.companyList.addCompany");
		};
		
		
		
	init();
		
	}]);
