function getCompaniesList(){
	 $.ajax({url: "data/companyList.json", success: function(result){
            getCompaniesTable(result);
        }});	
};

function getCompaniesTable(result){
	$('#companyDiv').css('display' , 'block');
	var len = Object.keys(result).length;
	if($("#companyTable tbody").length == 0){
		$("#companyTable").append('<tbody></tbody>')
		for(var i=0; i<len; i++){
			$("#companyTable tbody").append('<tr>'+
												'<td>'+result[i].name+'</td>'+
												'<td>'+result[i].established+'</td>'+
												'<td>'+result[i].employees+'</td>'+
												'<td>'+result[i].revenue+'</td>'+
												'<td><button onclick="onEditCompany(this)"><span class="glyphicon glyphicon-edit">Edit</span></button></td>'+
												'<td><button onclick="onDeleteCompany(this)"><span class="glyphicon glyphicon-remove">Delete</span></button></td>'+
											'</tr>');
		}
		tablePagination();
	}
};

function onDeleteCompany(company){
	$(company).parents('tr').remove();
};

function onEditCompany(company){
	$('#editFields').css('display' , 'block');
	row = $(company).parents('tr');
	$('td', row).each(function(i) {
		$('#editFields input').eq(i).val(this.textContent);
	});

};

function onCancelCompany(){
	$('#editFields').css('display' , 'none');
};

function onClickAdvanceSearch(){
	$('#advanceSearch').css('display','block');
};

$("#searchBar").keyup(function () {
    var value = $(this).val();

    if (value.length){
        $("table tr").each(function (index) {
            if (index != 0) {

                $row = $(this);

                $row.find("td").each(function () {

					var cell = $(this).text();

					if (cell.indexOf(value) < 0) {
						$row.hide();
					} else {
						$row.show();
						return false; //Once it's shown you don't want to hide it on the next cell
					}

				});
			}
		});
	}
	else{
		//if empty search text, show all rows
		$("table tr").show();

	}
});
