angular.module('myapp', ['ui.router' , 'myapp-company'])
    .config(function($stateProvider, $urlRouterProvider){

      $urlRouterProvider.otherwise("/home");

      $stateProvider
          
          .state('home', {
              url: '/home',
              templateUrl: 'views/home.html',
             
          })
		  .state('home.company', {
              url: '/company',
              templateUrl: 'views/company/companypanel.html',
             
		  })
		  .state('home.company.companyList', {
              url: '/companyList',
              templateUrl: 'views/company/companyList.html',
			  controller: 'companyctrl',
			 
              
		   })
		   .state('home.company.companyList.editCompany', {
              url: '/editCompany',
              templateUrl: 'views/company/editCompany.html',
			  controller: 'companyctrl',
              
          })
		   .state('home.company.companyList.addCompany', {
              url: '/addCompany',
              templateUrl: 'views/company/newCompany.html',
			  controller: 'companyctrl',
              
          })
		 
		  .state('home.employee', {
              url: '/employee',
              templateUrl: 'views/employee/employeePanel.html',
             
          });
    });
